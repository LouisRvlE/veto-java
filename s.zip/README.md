"# veto-java"

mvnw clean spring-boot:run

http://localhost:8080/api/animal/
http://localhost:8080/api/client/

http://localhost/phpmyadmin/
